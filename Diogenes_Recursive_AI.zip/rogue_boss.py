
class RogueBossMechanic:
    def __init__(self, config_file):
        self.config = self.load_config(config_file)

    def load_config(self, config_file):
        """Loads Rogue Boss mechanic configurations from a JSON file."""
        with open(config_file, 'r') as file:
            return json.load(file)

    def generate_boss_encounter(self, player_level):
        """Generates a rogue boss encounter based on the player's level."""
        difficulty = self.config.get("difficulty", {})
        level_modifier = difficulty.get(str(player_level), 1)

        # Create boss encounter based on difficulty and player level
        boss_stats = {stat: value * level_modifier for stat, value in self.config["boss_stats"].items()}
        print(f"Generated Boss Encounter: {boss_stats}")
        return boss_stats
