
class FailSafeConfig:
    def __init__(self, config_file):
        self.config = self.load_config(config_file)

    def load_config(self, config_file):
        """Loads fail-safe settings from a JSON file."""
        with open(config_file, 'r') as file:
            return json.load(file)

    def trigger_fail_safe(self, system_name):
        """Triggers a fail-safe action if the system has an error."""
        if system_name in self.config.get("fail_safes", {}):
            action = self.config["fail_safes"][system_name]
            print(f"Triggering fail-safe action: {action}")
            # Execute the fail-safe action here (e.g., reset system, alert player, etc.)
