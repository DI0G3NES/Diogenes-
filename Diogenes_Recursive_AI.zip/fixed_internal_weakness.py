
class InternalWeaknessEngine:
    def __init__(self, config_file):
        self.config = self.load_config(config_file)

    def load_config(self, config_file):
        """Loads internal weakness context from a JSON file."""
        with open(config_file, 'r') as file:
            return json.load(file)

    def apply_weakness(self, player):
        """Applies internal weaknesses to a player character."""
        for weakness in self.config.get("weaknesses", []):
            if weakness["type"] == "fear":
                # Adjust stats with safeguards against flipping negative morality
                adjusted_effect = weakness["effect"]
                
                # Prevent morality flip: Ensure negative values remain negative
                if adjusted_effect < 0 and player["morality"] > 0:
                    adjusted_effect = max(adjusted_effect, -player["morality"])

                player.adjust_stats(adjusted_effect)
                print(f"Applied weakness: {weakness['type']} with adjusted effect {adjusted_effect}")
