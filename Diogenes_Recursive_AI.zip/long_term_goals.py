
class LongTermEducationalGoals:
    def __init__(self, config_file):
        self.config = self.load_config(config_file)

    def load_config(self, config_file):
        """Loads long-term educational goals from a JSON file."""
        with open(config_file, 'r') as file:
            return json.load(file)

    def apply_educational_goals(self, player, progress):
        """Applies educational goals based on player progress."""
        goals = self.config.get("goals", [])
        for goal in goals:
            if progress >= goal["threshold"]:
                player.complete_goal(goal)
                print(f"Completed Goal: {goal['name']}")
