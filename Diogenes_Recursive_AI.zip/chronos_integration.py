
import json

class ChronosIntegration:
    def __init__(self, config_file):
        self.config = self.load_config(config_file)

    def load_config(self, config_file):
        """Loads configuration from a JSON file."""
        with open(config_file, 'r') as file:
            return json.load(file)

    def apply_chronos_effects(self, player, event):
        """Applies Chronos-based effects on a player during an event."""
        effects = self.config.get("effects", [])
        for effect in effects:
            if event in effect['trigger']:
                player.adjust_attributes(effect['attribute'], effect['value'])
                print(f"Applied {effect['attribute']} change: {effect['value']}")
