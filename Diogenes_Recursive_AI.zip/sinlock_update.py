
import random

# Define the initial world state for the simulation
world_state = {
    "Corruption": 0.6,  # High corruption (affects resource distribution, ethics)
    "Economic Instability": 0.7,  # High instability (affects society's ability to stabilize)
    "Technological Growth": 0.4,  # Moderate growth (affects innovation, risk of unchecked tech)
    "Moral Cohesion": 0.3  # Low cohesion (affects global solidarity, rising extremism)
}

# Define pseudoquant influence parameters for the simulation
pseudoquant_params = {
    "Corruption": 1.2,  # Scales corruption impact on resource scarcity or tyranny
    "Economic Instability": 1.5,  # Scales economic instability risk of societal collapse or war
    "Technological Growth": 0.8,  # Scales tech growth; low tech could mean more risks in AI and biotech
    "Moral Cohesion": 0.6  # Scales moral decline; low moral cohesion means more extremist ideologies
}

# Define threat categories and their triggers
threats = {
    "Resource Scarcity & Tyranny": {
        "trigger": "Corruption",
        "threshold": 0.5,  # Corruption over this level increases likelihood of resource hoarding and oppression
        "scale": 1.2,  # Scaling factor for severity based on pseudoquant value
        "description": "Global unrest due to monopolization of resources by corrupt factions, leading to wars and famines."
    },
    "Technological Overreach": {
        "trigger": "Technological Growth",
        "threshold": 0.6,  # If tech growth is below this, tech risks escalate into rogue AI or biotech disasters
        "scale": 1.5,
        "description": "Unchecked AI and biotech development leads to autonomous systems and bio-terrorism."
    },
    "Climate Chaos Ignored": {
        "trigger": "Economic Instability",
        "threshold": 0.7,  # High instability increases risk of ignoring climate change until it's too late
        "scale": 1.3,
        "description": "Environmental disasters intensify as global leaders fail to act on climate change, resulting in widespread displacement."
    },
    "Rising Extremist Factions": {
        "trigger": "Moral Cohesion",
        "threshold": 0.4,  # Low moral cohesion triggers the rise of extremist ideologies
        "scale": 1.5,
        "description": "Fractured societies give rise to extremist factions that push apocalyptic ideologies, destabilizing global peace."
    }
}

# Simulate threat generation based on world state
def generate_threats(world_state, pseudoquant_params, threats):
    generated_threats = []

    # Check each threat type based on its trigger and threshold
    for threat_name, threat_data in threats.items():
        trigger_value = world_state[threat_data["trigger"]]
        if trigger_value > threat_data["threshold"]:
            # Calculate the threat severity based on pseudoquant scaling
            threat_severity = trigger_value * pseudoquant_params[threat_data["trigger"]] * threat_data["scale"]
            generated_threats.append({
                "threat_name": threat_name,
                "severity": round(threat_severity, 2),
                "description": threat_data["description"]
            })
    return generated_threats

# Example: Calling the function to generate threats dynamically
simulated_threats = generate_threats(world_state, pseudoquant_params, threats)
for threat in simulated_threats:
    print(f"Threat: {threat['threat_name']}
Severity: {threat['severity']}
Description: {threat['description']}
")
    