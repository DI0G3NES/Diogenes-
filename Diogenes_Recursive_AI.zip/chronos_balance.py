
class ChronosBalanceGURPS:
    def __init__(self, config_file):
        self.config = self.load_config(config_file)

    def load_config(self, config_file):
        """Loads balance settings from a JSON file."""
        with open(config_file, 'r') as file:
            return json.load(file)

    def calculate_balance(self, player, difficulty_level):
        """Applies balance logic based on difficulty level and player stats."""
        modifiers = self.config.get("modifiers", {})
        difficulty_modifier = modifiers.get(str(difficulty_level), 1)
        
        # Adjust player stats or abilities based on modifiers
        adjusted_stats = {stat: value * difficulty_modifier for stat, value in player.stats.items()}
        print(f"Adjusted Stats: {adjusted_stats}")
        return adjusted_stats
